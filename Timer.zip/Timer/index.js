$(document).ready(function(){
  //start buttons and others
  $("#startoff").click(function(){
    $("#startoff").hide();
    $(".content").show();
  });
  $("#timerop").click(function(){
    $(".content").hide();
    $('#timerZero').hide();
    $('#timer').show();
  });
  $("#countdownop").click(function(){
    $(".content").hide();
    $("#gohome").hide();
    console.log("cd")
    $('#timerZero').hide();
    $('#timer').hide();
    $('#timercountdown').show();

  })   
  $("#gohome").click(function(){
    $(".content").hide();
    $("#startoff").show();
  })

    // timer 
  var timer = {
      hours : 0,
      minutes : 0,
      seconds : 0,
      intervalId : 0,
      start: function(){
          var thisfunc = this;
          $("#startbtn").prop("disabled",true);
          $("#timerHomebtn").prop("disabled",true);
          $("#resetbtn").prop("disabled", true);
          this.intervalId = setInterval(function(){
              console.log("start");
              thisfunc.seconds++;
              if(thisfunc.seconds > 60){
                  thisfunc.minutes++;
                  thisfunc.seconds = 0;  
              }
              if(thisfunc.minutes > 60){
                  thisfunc.hours++;
                  thisfunc.minutes = 0;
              }
              $("#hours").text(thisfunc.hours < 10 ? "0" + thisfunc.hours : thisfunc.hours);
              $("#mn").text(thisfunc.minutes < 10 ? "0" + thisfunc.minutes : thisfunc.minutes);
              $("#seconds").text(thisfunc.seconds < 10 ? "0" + thisfunc.seconds : thisfunc.seconds);
          },1000)

      },
      stop: function(){
          console.log('stop');
          clearInterval(this.intervalId);
          $("#startbtn").prop("disabled", false);
          $("#timerHomebtn").prop("disabled", false);
          $("#resetbtn").prop("disabled",false);
      },
      reset: function()
      {
          console.log('reset');       
          clearInterval(this.intervalId)
          this.hours = 0;
          this.minutes = 0;
          this.seconds = 0;
          $("#hours").text("00");
          $("#mn").text("00");
          $("#seconds").text("00");
          $("#startbtn").attr("onclick", "timer.start()");
          $("#timerHomebtn").attr("onclick","timer.home()");

      },
      home: function(){
        console.log("home");
        clearInterval(this.intervalId)
        this.hours = 0;
        this.minutes = 0;
        this.seconds = 0;
        $("#hours").text("00");
        $("#mn").text("00");
        $("#seconds").text("00");
          $("#timer").hide();
          $("#timerZero").show();
          $("#startoff").show();
      }
  };

  $("#startbtn").on("click",()=>{
    timer.start();
  });
  $("#stopbtn").on("click",()=>{
    timer.stop();
  });
  $("#resetbtn").on("click",()=>{
    timer.reset();
  });
  $("#timerHomebtn").on("click",()=>{
    timer.home();
  });


  // Countdown input Validation
  var validator = {
    hourInput: $("#hourinput"),
    mnInput: $("#mninput"),
    secondInput: $("#secondinput"),
    arr: ["0", "0"],
    init: function() {
      this.mnInput.val(this.arr[0] + this.arr[1]);
      this.secondInput.val(this.arr[0] + this.arr[1]);
      this.hourInput.val(this.arr[0] + this.arr[1]);
      this.addInputRestriction();
    },
    addInputRestriction: function() {
      [this.hourInput, this.mnInput, this.secondInput].forEach(input => {
        input.on("input", function(e) {
          var nonNumeric = /[^0-9]/g;
          var value = $(this).val();
          if (nonNumeric.test(value)) {
            $(this).val(value.replace(nonNumeric, ""));
          }
        });
      });
    },
    validateInputHour: function() {
      var num = Number(this.hourInput.val());
      if (Number.isInteger(num) && num >= 0 && num <= 99) {
        var str = num.toString().padStart(2, "0");
        this.arr[0] = str;
        this.hourInput.val(this.arr[0]);
        console.log(this.hourInput.val());
        console.log(this.arr[0]);
        console.log(this.arr[0].length);
      } else {
        console.log("else");
        console.log(this.hourInput.val());
        this.hourInput.val(this.arr[0]);
      }
    },
    validateInputMn: function() {
      var num = Number(this.mnInput.val());
      if (Number.isInteger(num) && num >= 0 && num <= 59) {
        var str = num.toString().padStart(2, "0");
        this.arr[0] = str;
        this.mnInput.val(this.arr[0]);
        console.log(this.arr);
        console.log(this.mnInput.val());
        console.log(this.arr[0].length);                     
      } else { 
        this.mnInput.val(this.arr[0]);
      }
    },
    validateInputSc: function() {
      var num = Number(this.secondInput.val());
      if (Number.isInteger(num) && num >= 0 && num <= 59) {
        var str = num.toString().padStart(2, "0");
        this.arr[0] = str;
        this.secondInput.val(this.arr[0]);
        console.log(this.arr);
        console.log(this.secondInput.val());
        console.log(typeof(this.secondInput.val()));
        console.log(this.arr[0].length);
      } else { 
        this.secondInput.val(this.arr[0]);
      }
    }
  };
  validator.init();
  $("#hourinput").on("input", ()=>{
    validator.validateInputHour();
  })
  $("#mninput").on("input", ()=>{
    validator.validateInputMn()
  })
  $("#secondinput").on("input", ()=>{
    validator.validateInputSc()
  })

  //Countdown 
  var Countdown = {
    intervalId: null,
    hourInput: $("#hourinput"),
    mnInput: $("#mninput"),
    secondInput: $("#secondinput"),
    start: function() {
      if( this.hourInput.val() == "00" && this.mnInput.val() == "00" && this.secondInput.val() == "00" ){
        return false;
      }else{
        this.intervalId = setInterval(this.update, 1000);
        $("#startCountdownbtn").prop( "disabled", true );
        $("#resetCountdownbtn").prop( "disabled", true );
        $("#countdownbtnHome").prop("disabled", true);
        $("#hourinput").prop("disabled", true);
        $("#mninput").prop("disabled",true);
        $("#secondinput").prop("disabled",true);
      }
    },
    update: function() {
      var h = parseInt(Countdown.hourInput.val());
      var mn = parseInt(Countdown.mnInput.val());
      var s = parseInt(Countdown.secondInput.val());
        console.log("start");
        console.log(h);
        s--;
      if(s < 0 ){
        s = 59;
        mn--;
    }
    if(mn < 0 ){
      mn = 59;
      h--;
    }
      Countdown.hourInput.val(h < 10 ? "0" + h : h);
      Countdown.mnInput.val(mn < 10 ? "0" + mn : mn);
      Countdown.secondInput.val(s < 10 ? "0" + s : s);
      if(h == 0 && mn == 0 && s == 0){
        alert("Your time is up");
        clearInterval(this.intervalId); 
      }
    },
    stop: function() {
      console.log('stop');
      clearInterval(this.intervalId);
      $("#startCountdownbtn").prop( "disabled", false );
      $("#resetCountdownbtn").prop( "disabled", false );
      $("#countdownbtnHome").prop("disabled", false);

    },
    reset: function() {
      console.log("reset");
      clearInterval(this.intervalId);
      this.hourInput.val("00");
      this.mnInput.val("00");
      this.secondInput.val("00");
      $("#hourinput").prop("disabled", false);
      $("#mninput").prop("disabled",false);
      $("#secondinput").prop("disabled",false);
    },
    home: function(){
      clearInterval(this.intervalId);
      this.hourInput.val("00");
      this.mnInput.val("00");
      this.secondInput.val("00");
      $("#timercountdown").hide();
      $("#timerZero").show();
      $("#startoff").show();
      $("#hourinput").prop("disabled", false);
      $("#mninput").prop("disabled",false);
      $("#secondinput").prop("disabled",false);
    }
  };
  $("#startCountdownbtn").on("click",()=>{
    Countdown.start();
  })
  $("#stopCountdownbtn").on("click",()=>{
    Countdown.stop();
  })
  $("#resetCountdownbtn").on("click",()=>{
    Countdown.reset();
  })
  $("#countdownbtnHome").on("click",()=>{
    Countdown.home();
  })


})